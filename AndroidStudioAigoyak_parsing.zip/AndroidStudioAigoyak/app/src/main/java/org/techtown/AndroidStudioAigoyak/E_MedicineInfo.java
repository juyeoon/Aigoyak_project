package org.techtown.AndroidStudioAigoyak;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class E_MedicineInfo  extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.medicine_info);
    }
}