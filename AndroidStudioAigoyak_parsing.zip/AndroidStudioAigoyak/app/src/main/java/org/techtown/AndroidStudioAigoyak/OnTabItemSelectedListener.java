package org.techtown.AndroidStudioAigoyak;
import android.view.View;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
    public void showFragment2(Note Item);
}
