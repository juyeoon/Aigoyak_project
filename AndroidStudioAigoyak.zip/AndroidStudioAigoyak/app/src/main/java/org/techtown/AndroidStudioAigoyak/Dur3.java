package org.techtown.AndroidStudioAigoyak;

public class Dur3 {

    String code;
    String code2;
    String code_name;
    String content;


    public Dur3(){

    }

    public String getCode(){
        return code;
    }
    public void setCode(String code){
        this.code = code;
    }


    public String getCode2(){
        return code2;
    }
    public void setCode2(String code2){
        this.code2 = code2;
    }

    public String getCodeName(){
        return code_name;
    }
    public void setCodeName(String code_name){
        this.code_name = code_name;
    }

    public String getContent(){ return content; }
    public void setContent(String content){ this.content = content; }

}
