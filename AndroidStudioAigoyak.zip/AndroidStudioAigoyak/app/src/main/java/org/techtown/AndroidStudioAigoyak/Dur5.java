package org.techtown.AndroidStudioAigoyak;

public class Dur5 {

    String code;
    String limit_nm;
    String unit;
    String standard;
    String content;


    public Dur5(){

    }

    public String getCode(){
        return code;
    }
    public void setCode(String code){
        this.code = code;
    }


    public String getLimit_nm(){
        return limit_nm;
    }
    public void setLimit_nm(String limit_nm){
        this.limit_nm = limit_nm;
    }

    public String getUnit(){
        return unit;
    }
    public void setUnit(String unit){
        this.unit = unit;
    }

    public String getStandard(){
        return standard;
    }
    public void setStandard(String standard){
        this.standard = standard;
    }

    public String getContent(){ return content; }
    public void setContent(String content){ this.content = content; }

}
