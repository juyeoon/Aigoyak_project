package org.techtown.AndroidStudioAigoyak;

public class Dur2 {

    String code;
    String content;


    public Dur2(){

    }

    public String getCode(){
        return code;
    }
    public void setCode(String code){
        this.code = code;
    }

    public String getContent(){ return content; }
    public void setContent(String content){ this.content = content; }

}
