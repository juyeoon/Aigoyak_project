package org.techtown.AndroidStudioAigoyak;
import android.view.View;

public interface OnNoteItemClickListener {
    public void onItemClick(B_MedicationList.ViewHolder holder, View view, int position);
}